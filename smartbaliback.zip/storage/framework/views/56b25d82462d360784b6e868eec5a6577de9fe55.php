
<?php $__env->startSection('title', 'Wisata'); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel-header">
        <div class="page-inner">
            <div class="page-header">
                <h4 class="page-title">Wisata</h4>
                <ul class="breadcrumbs">
                    <li class="nav-home">
                        <a href="<?php echo e(url('/admin/dashboard')); ?>">
                            <i class="flaticon-home"></i>
                        </a>
                    </li>
                    <li class="separator">
                        <i class="flaticon-right-arrow"></i>
                    </li>
                    <li class="nav-item">
                        <a href="#">Wisata</a>
                    </li>
                </ul>
            </div>
            <h4 class="page-title">Daftar Wisata</h4>
            <div class="row place" id="tour-cards">
                
            </div>
        </div>
    </div>
    <div class="page-inner mt--5">
        
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <!-- My Script -->
    <script src="<?php echo e(asset('t_admin/js/admin/tempat/index.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\smartbaliback\resources\views/admin/wisata/index.blade.php ENDPATH**/ ?>