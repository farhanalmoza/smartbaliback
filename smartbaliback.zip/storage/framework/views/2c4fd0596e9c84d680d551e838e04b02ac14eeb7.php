<?php $__env->startSection('title', 'Register'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-4 mx-auto">
    <div class="card">
      <div class="card-body">
        <div class="card-title fw-bold text-uppercase text-center">Sign up</div>
        <div class="card-body pb-0">
          <form action="<?php echo e(route('register')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
              <div class="input-icon <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <span class="input-icon-addon">
                  <i class="fa fa-user"></i>
                </span>
                <input id="name" name="name" type="text" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="Full name" autofocus>
              </div>
              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block text-danger">
                  <small><?php echo e($message); ?></small>  
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <div class="input-icon <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <span class="input-icon-addon">
                  <i class="fa fa-envelope"></i>
                </span>
                <input id="email" name="email" type="text" class="form-control" value="<?php echo e(old('email')); ?>" placeholder="Email" autocomplete="email">
              </div>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block text-danger">
                  <small><?php echo e($message); ?></small>  
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <div class="input-icon <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <span class="input-icon-addon">
                  <i class="fa fa-lock"></i>
                </span>
                <input id="password" name="password" type="password" class="form-control" placeholder="Password">
              </div>
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="help-block text-danger">
                  <small><?php echo e($message); ?></small>  
                </span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
              <div class="input-icon">
                <span class="input-icon-addon">
                  <i class="fa fa-lock"></i>
                </span>
                <input id="password-confirm" name="password_confirmation" type="password" class="form-control" placeholder="Password confirmation">
              </div>
            </div>
            <div class="row">
              <button type="submit" class="btn btn-primary mx-auto">Sign up</button>
            </div>
            <div class="row mt-3">
              <h5 class="col-sm-12">Already have an account? <a href="<?php echo e(route('login')); ?>" class="text-primary"> Login</a></h5>
            </div>
          </form>
        </div>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('components.auth.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\smartbaliback\resources\views/auth/register.blade.php ENDPATH**/ ?>